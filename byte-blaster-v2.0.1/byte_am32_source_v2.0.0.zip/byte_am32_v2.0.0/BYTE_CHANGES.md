# byte_am32 2.0.0

Modified AM32 distribution prepared 2026-11-06.
The source retains upstream copyright and license notices. Changes from upstream
include Byte long-reply telemetry, Byte configuration and arming-sound support,
startup behavior options, and the release build configuration.

Recorded modified-source revision: `6e708a539f06aa3ea960293ff96437bf2c4495a0`.
The added release wrapper selects the configuration used by the accompanying HEX.
This source snapshot omits development notes, CI settings, Git history and vendor
compiled help manuals. Firmware build inputs, original build scripts and license
notices are retained.
