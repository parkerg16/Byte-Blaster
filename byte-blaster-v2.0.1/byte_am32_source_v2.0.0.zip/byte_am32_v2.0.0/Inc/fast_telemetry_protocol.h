#ifndef AM32_FAST_TELEMETRY_PROTOCOL_H
#define AM32_FAST_TELEMETRY_PROTOCOL_H

/* Shared, platform-independent wire format. No packed structs on the wire. */
#include <stdint.h>
#include <stddef.h>
#define FT_SYNC 0xA5u
#define FT_VERSION 2u
#define FT_PACKET_SIZE 13u
#define FT_SENSOR_CONFIRMED 0x01u
#define FT_VOLTAGE_CONFIRMED 0x02u
#define FT_PEAK_MEDIAN3 0x04u
#define FT_CLIPPED 0x08u /* Current only; v1 also used this for other fields. */
#define FT_ACQUISITION_FAULT 0x10u /* Diagnostic validity only; no motor shutdown. */
#define FT_TX_DROPPED 0x20u
#define FT_VOLTAGE_CLIPPED 0x40u
#define FT_TEMPERATURE_CLIPPED 0x80u
#define FT_MIN_CURRENT_SAMPLES 8u

typedef struct {
    int16_t average_dA, peak_dA;
    uint16_t voltage_cV;
    int8_t temperature_C;
    uint8_t sequence, flags, samples;
} ft_sample_t;

static inline uint8_t ft_crc8(const uint8_t *bytes, size_t size)
{
    uint8_t crc = 0;
    while (size--) {
        crc ^= *bytes++;
        for (unsigned i = 0; i < 8; ++i)
            crc = (uint8_t)((crc & 0x80u) ? ((unsigned)crc << 1) ^ 0x07u : (unsigned)crc << 1);
    }
    return crc;
}
static inline void ft_put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static inline uint16_t ft_get16(const uint8_t *p) { return (uint16_t)(p[0] | ((uint16_t)p[1] << 8)); }
static inline int16_t ft_signed16(uint16_t v) { return (int16_t)(v <= 32767u ? (int32_t)v : (int32_t)v - 65536); }
static inline void ft_encode(uint8_t *p, const ft_sample_t *s)
{
    p[0] = FT_SYNC; p[1] = FT_VERSION; p[2] = s->sequence; p[3] = s->flags;
    ft_put16(p + 4, (uint16_t)s->average_dA); ft_put16(p + 6, (uint16_t)s->peak_dA);
    ft_put16(p + 8, s->voltage_cV); p[10] = (uint8_t)s->temperature_C;
    p[11] = s->samples; p[12] = ft_crc8(p, 12);
}
static inline int ft_decode(const uint8_t *p, ft_sample_t *s)
{
    if (p[0] != FT_SYNC || p[1] != FT_VERSION || ft_crc8(p, 12) != p[12]) return 0;
    s->sequence = p[2]; s->flags = p[3];
    s->average_dA = ft_signed16(ft_get16(p + 4)); s->peak_dA = ft_signed16(ft_get16(p + 6));
    s->voltage_cV = ft_get16(p + 8);
    s->temperature_C = (int8_t)(p[10] <= 127u ? (int)p[10] : (int)p[10] - 256);
    s->samples = p[11]; return 1;
}

typedef struct {
    uint8_t bytes[FT_PACKET_SIZE], used, have_sequence, last_sequence;
    uint32_t packets, crc_errors, lost_packets, duplicates, sequence_resets;
} ft_parser_t;

static inline void ft_parser_reset(ft_parser_t *p) { p->used = 0; p->have_sequence = 0; }
/* Sliding scan preserves embedded sync bytes after corrupt/partial frames. */
static inline int ft_parser_feed(ft_parser_t *p, uint8_t byte, ft_sample_t *s)
{
    p->bytes[p->used++] = byte;
    while (p->used) {
        if (p->bytes[0] == FT_SYNC && (p->used < 2 || p->bytes[1] == FT_VERSION)) {
            if (p->used < FT_PACKET_SIZE) return 0;
            if (ft_decode(p->bytes, s)) {
                p->used = 0; ++p->packets;
                if (p->have_sequence) {
                    uint8_t delta = (uint8_t)(s->sequence - p->last_sequence);
                    if (delta == 0) ++p->duplicates;
                    else if (delta < 128) p->lost_packets += (uint32_t)delta - 1;
                    else ++p->sequence_resets;
                }
                p->last_sequence = s->sequence; p->have_sequence = 1; return 1;
            }
            ++p->crc_errors;
        }
        --p->used;
        for (unsigned i = 0; i < p->used; ++i) p->bytes[i] = p->bytes[i + 1];
    }
    return 0;
}
#endif
