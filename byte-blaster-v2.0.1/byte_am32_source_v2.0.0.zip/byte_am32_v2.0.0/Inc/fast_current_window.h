#ifndef AM32_FAST_CURRENT_WINDOW_H
#define AM32_FAST_CURRENT_WINDOW_H
#include "fast_telemetry_protocol.h"
#include <limits.h>

typedef struct {
    uint32_t sum_current, sum_voltage;
    uint16_t minimum, maximum, previous[2];
    uint8_t count, flags, current_zero, history;
} ft_window_t;
/* Start the next contiguous window; median history carries across the boundary. */
static inline void ft_window_restart(ft_window_t *w)
{
    w->sum_current = w->sum_voltage = 0; w->count = w->flags = w->current_zero = 0;
    w->minimum = UINT16_MAX; w->maximum = 0;
}
static inline void ft_window_reset(ft_window_t *w)
{
    ft_window_restart(w);
    w->previous[0] = w->previous[1] = 0; w->history = 0;
}
static inline uint16_t ft_median3(uint16_t a, uint16_t b, uint16_t c)
{
    if (a > b) { uint16_t t = a; a = b; b = t; }
    if (b > c) { b = c; }
    return a > b ? a : b;
}
static inline void ft_window_add(ft_window_t *w, uint16_t current, uint16_t voltage)
{
    if (w->count == UINT8_MAX) { w->flags |= FT_ACQUISITION_FAULT; return; }
    w->sum_current += current; w->sum_voltage += voltage;
    if (current == 0) w->current_zero = 1;
    if (current >= 4095) w->flags |= FT_CLIPPED;
    if (voltage >= 4095) w->flags |= FT_VOLTAGE_CLIPPED;
    if (w->history >= 2) {
        uint16_t m = ft_median3(w->previous[0], w->previous[1], current);
        if (m < w->minimum) w->minimum = m;
        if (m > w->maximum) w->maximum = m;
        w->flags |= FT_PEAK_MEDIAN3;
    }
    w->previous[0] = w->previous[1]; w->previous[1] = current; ++w->count;
    if (w->history < 2) ++w->history;
}
/* Millivolts offset, signed millivolts/A slope; retain fractions until division. */
static inline int16_t ft_current_dA(uint32_t sum, uint8_t count, int32_t offset_mV,
                                  int32_t slope_mV_A, uint8_t *flags)
{
    if (!count || !slope_mV_A) { *flags |= FT_ACQUISITION_FAULT; return 0; }
    int64_t v = (((int64_t)sum * 3300 - (int64_t)count * offset_mV * 4095) * 10)
              / ((int64_t)count * 4095 * slope_mV_A);
    if (v > INT16_MAX) { *flags |= FT_CLIPPED; return INT16_MAX; }
    if (v < INT16_MIN) { *flags |= FT_CLIPPED; return INT16_MIN; }
    return (int16_t)v;
}
/* Fine calibration for fractional mV/A slopes and sub-mV zero offsets. */
static inline int16_t ft_current_uv_dA(uint32_t sum, uint8_t count, int32_t offset_uV,
                                     int32_t slope_uV_A, uint8_t *flags)
{
    if (!count || !slope_uV_A) { *flags |= FT_ACQUISITION_FAULT; return 0; }
    int64_t v = (((int64_t)sum * 3300000 - (int64_t)count * offset_uV * 4095) * 10)
              / ((int64_t)count * 4095 * slope_uV_A);
    if (v > INT16_MAX) { *flags |= FT_CLIPPED; return INT16_MAX; }
    if (v < INT16_MIN) { *flags |= FT_CLIPPED; return INT16_MIN; }
    return (int16_t)v;
}
#endif
