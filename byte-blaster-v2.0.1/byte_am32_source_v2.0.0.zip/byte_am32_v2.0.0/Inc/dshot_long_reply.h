#ifndef AM32_DSHOT_LONG_REPLY_H
#define AM32_DSHOT_LONG_REPLY_H

/* Long bidirectional DShot reply, shared by AM32 and the RP2040 controller.
 * Opt-in at runtime: the controller sends DLR_CMD_ENABLE six or more times
 * while armed and stopped; the ESC replies in this format until it resets.
 *
 * 72 data bits, MSB first, GCR (4b/5b) coded like the stock reply, then sent
 * as transition-coded line levels with a leading start bit: 1 + 90 = 91 bits.
 *   eRPM/10 17 | current 0.01 A 15 | voltage 0.01 V 13 | duty 0..2047 11 |
 *   temperature degC (signed) 8 | CRC-8 (poly 0x07) over the first 8 bytes 8
 * A current of DLR_CURRENT_INVALID means no fresh or valid measurement. */
#include <stdint.h>

#define DLR_CMD_ENABLE 42u
#define DLR_CMD_DISABLE 43u
#define DLR_DATA_BYTES 9u
#define DLR_NIBBLES 18u
#define DLR_GCR_BITS 90u
#define DLR_LINE_BITS 91u
#define DLR_STOCK_LINE_BITS 21u
#define DLR_ERPM10_MAX 0x1FFFFu
#define DLR_CURRENT_INVALID 0x7FFFu
#define DLR_VOLTAGE_MAX 0x1FFFu
#define DLR_DUTY_MAX 0x7FFu

typedef struct {
    uint32_t erpm10;
    uint16_t current_cA, voltage_cV, duty;
    int8_t temperature_C;
} dlr_reply_t;

static const uint8_t dlr_gcr_encode[16] = {
    0x19, 0x1B, 0x12, 0x13, 0x1D, 0x15, 0x16, 0x17,
    0x1A, 0x09, 0x0A, 0x0B, 0x1E, 0x0D, 0x0E, 0x0F
};

static inline uint8_t dlr_crc8(const uint8_t *bytes, unsigned size)
{
    uint8_t crc = 0;
    while (size--) {
        crc ^= *bytes++;
        for (unsigned i = 0; i < 8; ++i)
            crc = (uint8_t)((crc & 0x80u) ? ((unsigned)crc << 1) ^ 0x07u : (unsigned)crc << 1);
    }
    return crc;
}

static inline uint32_t dlr_clamp(uint32_t v, uint32_t max) { return v > max ? max : v; }

static inline void dlr_pack(uint8_t out[DLR_DATA_BYTES], const dlr_reply_t *r)
{
    uint64_t v = (uint64_t)dlr_clamp(r->erpm10, DLR_ERPM10_MAX) << 47;
    v |= (uint64_t)dlr_clamp(r->current_cA, DLR_CURRENT_INVALID) << 32;
    v |= (uint64_t)dlr_clamp(r->voltage_cV, DLR_VOLTAGE_MAX) << 19;
    v |= (uint64_t)dlr_clamp(r->duty, DLR_DUTY_MAX) << 8;
    v |= (uint8_t)r->temperature_C;
    for (unsigned i = 0; i < 8; ++i) out[i] = (uint8_t)(v >> (56 - 8 * i));
    out[8] = dlr_crc8(out, 8);
}

static inline int dlr_unpack(const uint8_t in[DLR_DATA_BYTES], dlr_reply_t *r)
{
    if (dlr_crc8(in, 8) != in[8]) return 0;
    uint64_t v = 0;
    for (unsigned i = 0; i < 8; ++i) v = (v << 8) | in[i];
    r->erpm10 = (uint32_t)(v >> 47) & DLR_ERPM10_MAX;
    r->current_cA = (uint16_t)((v >> 32) & DLR_CURRENT_INVALID);
    r->voltage_cV = (uint16_t)((v >> 19) & DLR_VOLTAGE_MAX);
    r->duty = (uint16_t)((v >> 8) & DLR_DUTY_MAX);
    r->temperature_C = (int8_t)(uint8_t)v;
    return 1;
}

/* GCR bit k (0 = first on the wire) of a packed reply. */
static inline unsigned dlr_gcr_bit(const uint8_t bytes[DLR_DATA_BYTES], unsigned k)
{
    unsigned nibble = k / 5, bit = 4 - k % 5;
    uint8_t n = (uint8_t)((bytes[nibble >> 1] >> ((nibble & 1) ? 0 : 4)) & 0xF);
    return (dlr_gcr_encode[n] >> bit) & 1u;
}

/* Receiver side. levels[i] is line bit i (0 = start bit), as the PIO samples
 * it. A stock reply followed by idle-high line reads as 21 bits then all ones. */
enum { DLR_DECODE_ERROR = 0, DLR_DECODE_LONG = 1, DLR_DECODE_STOCK = 2 };

static inline int dlr_gcr_decode5(unsigned code)
{
    for (unsigned i = 0; i < 16; ++i) if (dlr_gcr_encode[i] == code) return (int)i;
    return -1;
}

/* words: the three RX FIFO words for one 91-bit read (autopush at 32 bits,
 * shift left; the last word holds the final 27 bits right-aligned).
 * On DLR_DECODE_STOCK, *stock16 is the stock 16-bit frame (12 data + 4 CRC)
 * before checksum validation, matching Pico_Bidir_DShot's raw decoding. */
static inline int dlr_decode_words(const uint32_t words[3], dlr_reply_t *r, uint16_t *stock16)
{
    uint8_t lv[DLR_LINE_BITS];
    for (unsigned i = 0; i < 32; ++i) lv[i] = (uint8_t)((words[0] >> (31 - i)) & 1u);
    for (unsigned i = 0; i < 32; ++i) lv[32 + i] = (uint8_t)((words[1] >> (31 - i)) & 1u);
    for (unsigned i = 0; i < 27; ++i) lv[64 + i] = (uint8_t)((words[2] >> (26 - i)) & 1u);
    unsigned tail_ones = 1;
    for (unsigned i = DLR_STOCK_LINE_BITS; i < DLR_LINE_BITS; ++i) tail_ones &= lv[i];
    unsigned nibbles = tail_ones ? 4 : DLR_NIBBLES;
    uint8_t bytes[DLR_DATA_BYTES] = {0};
    uint16_t stock = 0;
    for (unsigned n = 0; n < nibbles; ++n) {
        unsigned code = 0;
        for (unsigned b = 0; b < 5; ++b) {
            unsigned i = 1 + 5 * n + b;   /* transition from line bit i-1 to i */
            code = (code << 1) | (unsigned)(lv[i] ^ lv[i - 1]);
        }
        int d = dlr_gcr_decode5(code);
        if (d < 0) return DLR_DECODE_ERROR;
        if (tail_ones) stock = (uint16_t)((stock << 4) | (unsigned)d);
        else bytes[n >> 1] |= (uint8_t)((unsigned)d << ((n & 1) ? 0 : 4));
    }
    if (tail_ones) { *stock16 = stock; return DLR_DECODE_STOCK; }
    return dlr_unpack(bytes, r) ? DLR_DECODE_LONG : DLR_DECODE_ERROR;
}

#endif
