#ifndef AM32_FAST_CURRENT_TELEMETRY_H
#define AM32_FAST_CURRENT_TELEMETRY_H
#include <stdint.h>
#include "targets.h"
/* Opt-in: build with -DFAST_CURRENT_TELEMETRY=1 (build_fast_telemetry.ps1 -Fast).
 * Enables fast ADC acquisition and the optional long DShot reply. The 1 kHz
 * stream on the TLM pin is a separate opt-in (FAST_TELEMETRY_UART). */
#ifndef FAST_CURRENT_TELEMETRY
#define FAST_CURRENT_TELEMETRY 0
#endif
/* Learn the current zero while armed and stopped (long DShot reply only). */
#ifndef FAST_CURRENT_AUTO_ZERO
#define FAST_CURRENT_AUTO_ZERO 0
#endif
#ifndef FAST_CURRENT_RAW_MV_DIAG
#define FAST_CURRENT_RAW_MV_DIAG 0
#endif
#ifndef FAST_TELEMETRY_UART
#define FAST_TELEMETRY_UART 0
#endif
#if FAST_CURRENT_TELEMETRY
#define DSHOT_GCR_LEN 104 /* room for the 91-bit long reply plus padding */
#else
#define DSHOT_GCR_LEN 37
#endif
#if FAST_TELEMETRY_UART && !FAST_CURRENT_TELEMETRY
#error "FAST_TELEMETRY_UART requires FAST_CURRENT_TELEMETRY"
#endif
#ifndef FAST_TELEMETRY_BAUD
#define FAST_TELEMETRY_BAUD 500000
#endif
#ifndef FAST_TELEMETRY_RATE_HZ
#define FAST_TELEMETRY_RATE_HZ 1000
#endif
/* Set only after board connectivity and physical calibration are verified. */
#ifndef FAST_CURRENT_SENSOR_CONFIRMED
#define FAST_CURRENT_SENSOR_CONFIRMED 0
#endif
#ifndef FAST_VOLTAGE_SENSOR_CONFIRMED
#define FAST_VOLTAGE_SENSOR_CONFIRMED 0
#endif
#ifndef FAST_CURRENT_OFFSET_UV
#define FAST_CURRENT_OFFSET_UV (CURRENT_OFFSET * 1000)
#endif
#ifndef FAST_CURRENT_UV_PER_AMP
#define FAST_CURRENT_UV_PER_AMP (MILLIVOLT_PER_AMP * 1000)
#endif
#if FAST_CURRENT_TELEMETRY
#if FAST_CURRENT_TELEMETRY != 1
#error "FAST_CURRENT_TELEMETRY must be 0 or 1"
#endif
#ifndef MCU_AT421
#error "Fast telemetry currently requires an F421 target"
#endif
#if FAST_TELEMETRY_UART && !defined(USE_SERIAL_TELEMETRY)
#error "The fast UART stream requires a target with serial telemetry"
#endif
#if defined(USE_ADC_INPUT) || defined(BRUSHED_MODE)
#error "Fast telemetry has not been ported to ADC-input or brushed targets"
#endif
#if FAST_TELEMETRY_RATE_HZ != 1000
#error "Only the 1000 Hz window scheduler is implemented"
#endif
#if FAST_TELEMETRY_UART && FAST_TELEMETRY_BAUD != 500000 && FAST_TELEMETRY_BAUD != 1000000
#error "13 bytes at 1 kHz exceed 115200 baud; select 500000 or 1000000"
#endif
#if FAST_CURRENT_UV_PER_AMP == 0
#error "Current calibration slope cannot be zero"
#endif
#if FAST_TELEMETRY_UART && defined(USE_PA14_TELEMETRY) && defined(USE_TIMER_3_CHANNEL_1)
#error "UART2 telemetry and TMR3 DShot both require DMA1 channel 4"
#endif
#if CPU_FREQUENCY_MHZ != 120
#error "Fast telemetry clock port requires the F421 120 MHz clock setup"
#endif
#define FT_CLOCK_MASK 0xFFFFFFu
#define FT_CLOCK_TICKS_PER_US (CPU_FREQUENCY_MHZ / 8u)
typedef struct { uint16_t current, voltage, temperature, ntc; } ft_adc_snapshot_t;
void fast_current_clock_init(void);
uint32_t fast_current_clock(void); /* 24-bit downcounter, HCLK/8; no IRQ */
void fast_current_hw_adc_stop(void);
void fast_current_hw_adc_start(void);
void fast_current_hw_adc_calibrate(void);
int fast_current_hw_adc_calibrated(void);
void fast_current_hw_tx_recover(void);
void fast_current_adc_ready(uint8_t healthy);
void fast_current_tick(void);
void fast_current_adc_complete(uint16_t current, uint16_t voltage, uint16_t temperature, uint16_t ntc);
void fast_current_adc_error(void);
void fast_current_poll(void);
int fast_current_adc_snapshot(ft_adc_snapshot_t *snapshot);
void fast_current_maintenance_begin(void);
void fast_current_maintenance_end(void);
/* Average since the previous call, for the long DShot reply. */
void fast_current_dshot_values(uint16_t *current_cA, uint16_t *voltage_cV);
extern uint8_t dshot_long_reply;
extern uint8_t gcr_dma_length;
#endif
#endif
