#ifndef AM32_CURRENT_MEASUREMENT_H
#define AM32_CURRENT_MEASUREMENT_H
#include <stdint.h>
#include <limits.h>
/* Preserve 12-bit protection scaling, but clamp before publishing its
 * centiampere result. Never expose a negative or wrapped ISR input. */
static inline int16_t am32_protection_current_cA(uint16_t raw, int32_t offset_mV,
                                               int32_t slope_mV_A)
{
    if (!slope_mV_A) return INT16_MAX;
    int64_t value = (((int64_t)raw * 3300 / 41) - (int64_t)offset_mV * 100)
                    / slope_mV_A;
    if (value < 0) return 0;
    if (value > INT16_MAX) return INT16_MAX;
    return (int16_t)value;
}
#endif
