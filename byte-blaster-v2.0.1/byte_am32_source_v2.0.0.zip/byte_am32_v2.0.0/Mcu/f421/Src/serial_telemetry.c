///*
// * serial_telemetry.c
// *
// *  Created on: May 13, 2020
// *      Author: Alka
// */

#include "serial_telemetry.h"
#include "common.h"
#include "targets.h"
#include "kiss_telemetry.h"
#include "fast_current_telemetry.h"

#if FAST_TELEMETRY_UART
void fast_current_hw_tx_recover(void)
{
#ifdef USE_PA14_TELEMETRY
    DMA1_CHANNEL4->ctrl_bit.chen = FALSE;
    DMA1->clr = DMA1_GL4_FLAG;
    usart_reset(USART2);
#else
    DMA1_CHANNEL2->ctrl_bit.chen = FALSE;
    DMA1->clr = DMA1_GL2_FLAG;
    usart_reset(USART1);
#endif
    telem_UART_Init(); /* bounded peripheral setup; no transmit wait */
}
#endif

#ifdef USE_PA14_TELEMETRY

void send_telem_DMA(uint8_t bytes)
{ // set data length and enable channel to start transfer
    DMA1_CHANNEL4->ctrl_bit.chen = FALSE;
    DMA1_CHANNEL4->dtcnt = bytes;
    DMA1_CHANNEL4->ctrl_bit.chen = TRUE;
}

void telem_UART_Init(void)
{
    gpio_init_type gpio_init_struct;

    crm_periph_clock_enable(CRM_USART2_PERIPH_CLOCK, TRUE);
    crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);
    crm_periph_clock_enable(CRM_DMA1_PERIPH_CLOCK, TRUE);

    /* configure the usart2 tx pin on PA14 (SWCLK/TLM) */
    gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
    gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
    gpio_init_struct.gpio_pins = GPIO_PINS_14;
    gpio_init_struct.gpio_pull = GPIO_PULL_UP;
    gpio_init(GPIOA, &gpio_init_struct);
    gpio_pin_mux_config(GPIOA, GPIO_PINS_SOURCE14, GPIO_MUX_1);

    dma_reset(DMA1_CHANNEL4);

    dma_init_type dma_init_struct;
    dma_default_para_init(&dma_init_struct);
    dma_init_struct.buffer_size = sizeof(aTxBuffer);
    dma_init_struct.direction = DMA_DIR_MEMORY_TO_PERIPHERAL;
    dma_init_struct.memory_base_addr = (uint32_t)aTxBuffer;
    dma_init_struct.memory_data_width = DMA_MEMORY_DATA_WIDTH_BYTE;
    dma_init_struct.memory_inc_enable = TRUE;
    dma_init_struct.peripheral_base_addr = (uint32_t)&USART2->dt;
    dma_init_struct.peripheral_data_width = DMA_PERIPHERAL_DATA_WIDTH_BYTE;
    dma_init_struct.peripheral_inc_enable = FALSE;
    dma_init_struct.priority = DMA_PRIORITY_LOW;
    dma_init_struct.loop_mode_enable = FALSE;
    dma_init(DMA1_CHANNEL4, &dma_init_struct);

    /* configure usart2 param */
    usart_init(USART2, FAST_TELEMETRY_UART ? FAST_TELEMETRY_BAUD : 115200, USART_DATA_8BITS, USART_STOP_1_BIT);
    usart_transmitter_enable(USART2, TRUE);
    usart_receiver_enable(USART2, TRUE);
    usart_single_line_halfduplex_select(USART2, TRUE);
    usart_dma_transmitter_enable(USART2, TRUE);
    usart_enable(USART2, TRUE);
}

#else

void send_telem_DMA(uint8_t bytes)
{ // set data length and enable channel to start transfer
    DMA1_CHANNEL2->ctrl_bit.chen = FALSE;
    DMA1_CHANNEL2->dtcnt = bytes;
    DMA1_CHANNEL2->ctrl_bit.chen = TRUE;
}

void telem_UART_Init(void)
{
    gpio_init_type gpio_init_struct;

    crm_periph_clock_enable(CRM_USART1_PERIPH_CLOCK, TRUE);
    crm_periph_clock_enable(CRM_GPIOB_PERIPH_CLOCK, TRUE);
    crm_periph_clock_enable(CRM_DMA1_PERIPH_CLOCK, TRUE);

    /* configure the usart2 tx pin */
    gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
    gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
    gpio_init_struct.gpio_mode = GPIO_MODE_MUX;
    gpio_init_struct.gpio_pins = GPIO_PINS_6;
    gpio_init_struct.gpio_pull = GPIO_PULL_UP;
    gpio_init(GPIOB, &gpio_init_struct);
    gpio_pin_mux_config(GPIOB, GPIO_PINS_SOURCE6, GPIO_MUX_0);

    dma_reset(DMA1_CHANNEL2);

    dma_init_type dma_init_struct;
    dma_default_para_init(&dma_init_struct);
    dma_init_struct.buffer_size = sizeof(aTxBuffer);
    dma_init_struct.direction = DMA_DIR_MEMORY_TO_PERIPHERAL;
    dma_init_struct.memory_base_addr = (uint32_t)aTxBuffer;
    dma_init_struct.memory_data_width = DMA_MEMORY_DATA_WIDTH_BYTE;
    dma_init_struct.memory_inc_enable = TRUE;
    dma_init_struct.peripheral_base_addr = (uint32_t)&USART1->dt;
    dma_init_struct.peripheral_data_width = DMA_PERIPHERAL_DATA_WIDTH_BYTE;
    dma_init_struct.peripheral_inc_enable = FALSE;
    dma_init_struct.priority = DMA_PRIORITY_LOW;
    dma_init_struct.loop_mode_enable = FALSE;
    dma_init(DMA1_CHANNEL2, &dma_init_struct);

 //   DMA1_CHANNEL2->ctrl |= DMA_FDT_INT;
 //   DMA1_CHANNEL2->ctrl |= DMA_DTERR_INT;

    /* configure usart1 param */
    usart_init(USART1, FAST_TELEMETRY_UART ? FAST_TELEMETRY_BAUD : 115200, USART_DATA_8BITS, USART_STOP_1_BIT);
    usart_transmitter_enable(USART1, TRUE);
    usart_receiver_enable(USART1, TRUE);
    usart_single_line_halfduplex_select(USART1, TRUE);
    usart_dma_transmitter_enable(USART1, TRUE);
    usart_enable(USART1, TRUE);

    nvic_irq_enable(DMA1_Channel3_2_IRQn, 3, 0);
}

#endif
