# Build byte_am32 2.0.0

This source corresponds to the accompanying byte_am32 `F4A_4IN1_F421` HEX
and BIN. Upstream AM32 settings continue to report version 2.21.
Use the root `build_byte_am32.ps1` wrapper for this release configuration.

## Windows prerequisites

- PowerShell, Python 3, and GNU Make.
- xPack GNU Arm Embedded GCC **10.3.1-2.3** (compiler reports 10.3.1 20210824).
- Upstream Windows tools: https://firmware.ardupilot.org/Tools/AM32-tools/windows-tools.zip

Extract the upstream tools into this source directory so that
`tools/windows/make/bin/make.exe` and
`tools/windows/xpack-arm-none-eabi-gcc-10.3.1-2.3/bin/arm-none-eabi-gcc.exe`
exist. Python must be on PATH. Then run:

```powershell
./build_byte_am32.ps1
```

The wrapper builds the image, checks both release hashes and copies the resulting
HEX and BIN to the source root under their public release names. It does not flash
hardware. The optional protocol/driver tests can be run with
`./tools/scripts/test_fast_telemetry.ps1`; these also require native gcc and g++.

## Installation

Use matching Byte Blaster 2.0.0 firmware and configurator. Back up settings,
load the HEX through the configurator ESC Firmware tab, and keep target checking
enabled. This is a hardware-specific application image, not a universal F421
image. Confirm the board revision and electrical configuration match before
flashing. Target identity alone does not prove board compatibility.
The BIN begins at 0x08001000 and does not replace the bootloader.
After updating both ESCs, power-cycle, read back settings, check direction and
telemetry, and re-run FF/PID tuning. Original upstream installation guidance is
retained in README.md. No release-specific signing key is needed.

## License

AM32 is distributed under GPLv3; see LICENSE and the notices in individual files.
Vendor components retain their original notices and terms.
